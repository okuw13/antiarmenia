Kullanım Komutları
=

```python
	python instaBrute.py -f usernames.txt -d dictionary.txt
```
```python
	python instaBrute.py -u facebook -d dictionary.txt
```

Kullanım Videosu
=
https://www.youtube.com/watch?v=O3IegM-MEes

İrtibat Noktaları
=
- Website : http://turksiberguvenlik.net
- Youtube : https://youtube.com/user/pcdunyasi
- Facebook : https://facebook.com/bitekkan
	
